#!/bin/sh
java -jar PortablePGP.jar
